const playArea = document.getElementById('play-area');
const playerHand = document.getElementById('player-hand');
const opponentHand = document.getElementById('opponent-hand');

function displayCards(hand, cards) {
    hand.innerHTML = '';
    cards.forEach(card => {
        const cardEl = document.createElement('div');
        cardEl.classList.add('card');
        cardEl.style.backgroundImage = `url(${card.image})`;
        hand.appendChild(cardEl);
    });
}

function handlePlay(playerCard, opponentCard) {
    if (playerCard.value > opponentCard.value) {
        playArea.appendChild(playerCard.el);
    } else if (playerCard.value < opponentCard.value) {
        playArea.appendChild(opponentCard.el);
    } else {
        // Draw or tie logic can be added here
    }
}

function shuffleDeck(deck) {
    for (let i = deck.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [deck[i], deck[j]] = [deck[j], deck[i]];
    }
}

function drawCard(hand, deck) {
    if (deck.length === 0) return null;
    const card = deck.pop();
    hand.appendChild(card.el);
    return card;
}

function initializeGame() {
    const deck = [];
    for (let i = 0; i < 52; i++) {
        const card = { value: i % 13 + 1, image: `cards/${i % 13 + 1}.png` };
        deck.push(card);
    }
    shuffleDeck(deck);

    const playerCards = deck.slice(0, 7).map(card => ({ ...card, el: document.createElement('div') }));
    playerCards.forEach(card => card.el.classList.add('card'));
    playerCards.forEach(card => card.el.style.backgroundImage = `url(${card.image})`);
    playerHand.appendChild(...playerCards.map(card => card.el));

    const opponentCards = deck.slice(7, 14).map(card => ({ ...card, el: document.createElement('div') }));
    opponentCards.forEach(card => card.el.classList.add('card'));
    opponentCards.forEach(card => card.el.style.backgroundImage = `url(${card.image})`);
    opponentHand.appendChild(...opponentCards.map(card => card.el));
}

initializeGame();