class Card {
    constructor(rank, suit) {
        this.rank = rank;
        this.suit = suit;
    }

    render() {
        const cardElement = document.createElement('div');
        cardElement.classList.add('card');
        cardElement.style.backgroundImage = `url('cards.png')`;
        cardElement.style.backgroundPosition = `${this.rank * -10}px ${this.suit * -140}px`;
        return cardElement;
    }
}

function shuffleDeck(deck) {
    for (let i = deck.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [deck[i], deck[j]] = [deck[j], deck[i]];
    }
}

function dealCards(hand, numCards) {
    const deck = Array.from({ length: 52 }, (_, i) => new Card(i % 13, Math.floor(i / 13)));
    shuffleDeck(deck);
    for (let i = 0; i < numCards; i++) {
        hand.appendChild(deck.shift().render());
    }
}