document.addEventListener('DOMContentLoaded', () => {
    const playerHand = document.getElementById('player-hand');
    const opponentHand = document.getElementById('opponent-hand');
    const playArea = document.getElementById('play-area');

    // Define card dimensions and styles
    const CARD_WIDTH = 100;
    const CARD_HEIGHT = 140;

    // Create a deck of cards
    function createDeck() {
        const suits = ['Hearts', 'Diamonds', 'Clubs', 'Spades'];
        const values = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A'];
        let deck = [];

        for (let suit of suits) {
            for (let value of values) {
                deck.push({ suit, value });
            }
        }

        return deck;
    }

    // Shuffle the deck
    function shuffleDeck(deck) {
        for (let i = deck.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [deck[i], deck[j]] = [deck[j], deck[i]];
        }
    }

    // Deal cards to players
    function dealCards(deck, playerHand, opponentHand) {
        for (let i = 0; i < 5; i++) {
            playerHand.appendChild(createCardElement(deck.pop()));
            opponentHand.appendChild(createCardElement(deck.pop()));
        }
    }

    // Create a card element
    function createCardElement(card) {
        const cardElement = document.createElement('div');
        cardElement.classList.add('card');
        cardElement.style.width = `${CARD_WIDTH}px`;
        cardElement.style.height = `${CARD_HEIGHT}px`;
        cardElement.style.backgroundImage = `url(cards/${card.value.toLowerCase()}${card.suit[0]}.png)`;
        return cardElement;
    }

    // Initialize game
    const deck = createDeck();
    shuffleDeck(deck);
    dealCards(deck, playerHand, opponentHand);

    // Add event listeners for card interactions
    playerHand.addEventListener('click', (e) => {
        if (e.target.classList.contains('card')) {
            e.target.remove();
        }
    });

    // Load additional scripts
    import './hand.js';
    import './play.js';
});