class Hand {
    constructor(id) {
        this.id = id;
        this.cards = [];
    }

    addCard(card) {
        this.cards.push(card);
    }

    removeCard(card) {
        const index = this.cards.indexOf(card);
        if (index !== -1) {
            this.cards.splice(index, 1);
        }
    }

    shuffle() {
        for (let i = this.cards.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [this.cards[i], this.cards[j]] = [this.cards[j], this.cards[i]];
        }
    }

    draw(numCards) {
        return this.cards.splice(0, numCards);
    }

    displayHand() {
        const handElement = document.getElementById(`${this.id}-hand`);
        handElement.innerHTML = '';
        this.cards.forEach(card => {
            const cardElement = document.createElement('div');
            cardElement.classList.add('card', `player-${this.id}`);
            cardElement.style.backgroundImage = `url(${card.image})`;
            handElement.appendChild(cardElement);
        });
    }
}